----------------------------------------------
The Rome Total War VnV & TnT Cherry Vanilla Pack
[Corrected and augmented standard vice and virtue & trigger and trait systems]
 
Copyright (C) 2005 The Trivium Organization

v1.2.0 - 03/7/2005

Developers:.Spartan, Zrave, DrJambo

Special Thanks:

therother - beta testing
To everyone in the community who discovered bugs in the VnV and tnt files.

http://thetrivium.org
email: trivium@thetrivium.org

This software was developed for the Total War Center's (TWC) community in an effort to enhance its game play experience. 

The TWC's URL: http://www.twcenter.net/
The Trivium's forum at the TWC: http://www.twcenter.net/forums/index.php?showforum=56

Using The The Cherry Vanilla Pack
----------------------------------------------
The Cherry Vanilla Pack is meant to be used as a replacement set of standard "stock" files for Rome Total War. Please see the change list for specific details.

If you are not sure that you fully understand principles on which The Cherry Vanilla Pack operates we recommend you not to use it at this stage.

----------------------------------------------
Version History:
----------------------------------------------

1.00 - .Spartan, Zrave, Aquiantus
1.01 - .Spartan, Zrave
1.02 - .Spartan, Zrave
1.10 - .Spartan, Zrave
1.20 - .Spartan, Zrave, DrJambo

----------------------------------------------
Licence Agreement:
----------------------------------------------
Terms of Use
This Software is FREEWARE. This software is provided "as is", without any guarantee made as to its suitability or fitness for any particular use. You are granted a non-exclusive right and license to use the Software and the related documentation (the "Documentation") as set forth in this Agreement.For the purposes of protecting The Trivium and The Creative Assembly Limited trade secrets, you may not decompile, disassemble, reverse-engineer or otherwise display the Software in human-readable form. You may not modify, translate, rent, lease, distribute or lend the Software, and you may not sell to others the right to use the Software on your computer. You may not remove any proprietary notices or labels on the Software. You may not copy, transfer, transmit, sublicense or assign this license or the Software except as expressly permitted in this Agreement. You agree that the terms of this paragraph apply to the Software or any portion thereof, whether owned by The Trivium or The Creative Assembly Limited including without limitation Activision Corporation.

This Software may contain bugs, so use is at your own risk. We take no responsibility for any damage that may unintentionally be caused through its use. We have verified it on local systems and on a number of other users computers, but there is no way for us to be able to guarantee that it will work on each and every system configuration out there. However if you can run RTW then this should be fine.

Cooperation
You may not use this Software in a commercial product, without the express permission of The Trivium Organization or The Creative Assembly Limited When applicable. You may use this software in a free product as long as the Trivium is given credit and its contact information is included. If you are interested in redistributing the Software, either in original or modified form, or wish to use Software source code in a product, or have any other idea of cooperation, including job offers or a donations, please send e-mail to trivium@thetrivium.org with details.

Copyright Notice
The Trivium Organization holds valid copyright on our original work/software. Nothing in this agreement constitutes a waiver of any rights under U.S. Copyright law or any other federal or state law.

----------------------------------------------
File List:
----------------------------------------------
Restore Traits Backup.bat
Install Cherry Vanilla.bat
Backup My VnV Files.bat
CVP Readme.txt
Trivium\export_descr_character_traits.txt
Trivium\export_descr_VnVs_enums.txt
Trivium\text\export_VnVs.txt
URL Link Files for: TWC.net & Trivium.org
----------------------------------------------
Installation Instructions:
----------------------------------------------
1) Unzip into Rome Total War directory.

2) Run "Backup My VnV Files.bat" - This will make a new folder and store your previous traits files. They are made +r (Read Only) to prevent accidental overwriting.

3) Run "Install Cherry Vanilla.bat" - This will install the traits package.

You will need to close and reopen RTW if it was currently running, and you must start a new campaign.

The "Restore Traits Backup.bat" will restore your original traits settings.
----------------------------------------------
Latest Changes\ Update Log:
----------------------------------------------

===== The Cherry Vanilla Pack version: 1.2 ==== 

Main bug fixes in this version:
 
1) Combat traits no longer are doubled and work normally under autocalc

2) The scarface trait now works properly and all related microbugs fixed - it needed a new condition

- Specific Changes:

- export_descr_character_traits.txt

02/12

Mod295 - 02/12 : changed relationship to <=
Mod296 - 02/12 : changed relationship to <=
Mod297 - 02/12 : changed relationship to <=
Mod298 - 02/12 : removed trait
Mod299 - 02/12 : plateaued hp bonus at level 2
Mod300 - 02/12 : Changed briberesistance to 50% at level 3, 100% level 4
Mod301 - 02/12 : doubled threshold, changed briberesistance to 2/5/10 form 10/20/30, halved law bonus
Mod302 - 02/12 : reversed briberesistance to original
Mod303 - 02/12 : reversed briberesistance to original
Mod304 - 02/12 : reduced bribe resistance to 2/5/10 from 10/20/30, removed 4th level, doubled threshold
Mod305 - 02/12 : reduced bribe resistance to 2/5/10 from 10/20/30
Mod306 - 02/12 : reduced bribe resistance to 2/5/10 from 10/20/30
Mod307 - 02/12 : added antitrait mathematicsskill, increased briberesistance by -1/level
Mod308 - 02/12 : reversed squalor bonus to original
Mod309 - 02/12 : reduced briberesistance
Mod310 - 02/12 : reversed treasury requirement to original
Mod311 - 02/12 : reversed treasury requirement to original
Mod312 - 02/12 : reversed treasury requirement to original
Mod313 - 02/12 : reversed treasury requirement to original
Mod314 - 02/12 : removed hardtobribe
Mod315 - 02/12 : removed hardtobribe
Mod316 - 02/12 : removed trigger
Mod317 - 02/12 : doubled corrupt effect
Mod318 - 02/12 : reduced loyal chance to 75 from 100
Mod319 - 02/12 : doubled loyal effect, split up intelligent and natural military skill
Mod320 - 02/12 : doubled loyal effect
Mod321 - 02/12 : doubled loyal effect, split up intelligent and natural military skill
Mod322 - 02/12 : split up intelligent trigger
Mod323 - 02/12 : split up naturalmilitaryskill trigger
Mod324 - 02/12 : doubled loyal effect
Mod325 - 02/12 : doubled upright effect, removed risky* effect 
Mod326 - 02/12 : doubled upright effect
Mod327 - 02/12 : doubled upright effect
Mod328 - 02/12 : removed risky* effect
Mod329 - 02/12 : doubled threshold
Mod330 - 02/12 : doubled threshold
Mod331 - 02/12 : doubled plainromanvirtue, added goodcommander effect, doubled goodattacker and gooddefender
Mod332 - 02/12 : doubled goodcommander chance, increased intelligent and naturalmilitaryskill chance
Mod333 - 02/12 : increased handsome chance, added goodcommander chance
Mod334 - 02/12 : added goodcommander chance, doubled goodattacker, gooddefender, and goodsiegeattacker effects

02/14

Mod335 - 02/14 : increased tacticalskill chance to 10 from 5
Mod336 - 02/14 : increased tacticalskill chance to 10 from 5
Mod337 - 02/14 : doubled threshold
Mod338 - 02/14 : doubled threshold
Mod339 - 02/14 : doubled bloodthirsty effect
Mod340 - 02/14 : doubled bloodthirsty effect
Mod341 - 02/14 : doubled bloodthirsty effect
Mod342 - 02/14 : doubled bloodthirsty effect
Mod343 - 02/14 : doubled threshold
Mod344 - 02/14 : doubled glorious fool effect
Mod345 - 02/14 : doubled threshold
Mod346 - 02/14 : doubled battlescarred effect
Mod347 - 02/14 : doubled battlescarred effect
Mod348 - 02/14 : doubled threshold
Mod349 - 02/14 : doubled threshold
Mod350 - 02/14 : doubled badinfantrygeneral effect
Mod351 - 02/14 : doubled badinfantrygeneral effect
Mod352 - 02/14 : doubled badinfantrygeneral effect
Mod353 - 02/14 : doubled goodinfantrygeneral effect
Mod354 - 02/14 : doubled threshold
Mod355 - 02/14 : doubled threshold
Mod356 - 02/14 : doubled goodcavalrygeneral effect
Mod357 - 02/14 : doubled goodcavalrygeneral effect
Mod358 - 02/14 : doubled badcavalrygeneral effect
Mod359 - 02/14 : doubled goodcavalrygeneral effect
Mod360 - 02/14 : doubled threshold
Mod361 - 02/14 : doubled threshold
Mod362 - 02/14 : doubled threshold
Mod363 - 02/14 : doubled threshold
Mod364 - 02/14 : doubled threshold
Mod365 - 02/14 : doubled threshold
Mod366 - 02/14 : doubled threshold
Mod367 - 02/14 : doubled threshold
Mod368 - 02/14 : doubled threshold
Mod369 - 02/14 : doubled threshold
Mod370 - 02/14 : doubled threshold
Mod371 - 02/14 : doubled threshold
Mod372 - 02/14 : doubled threshold
Mod373 - 02/14 : doubled threshold
Mod374 - 02/14 : doubled HatesCarthaginians effect
Mod375 - 02/14 : doubled HatesRomans effect
Mod376 - 02/14 : doubled HatesBarbarians effect
Mod377 - 02/14 : doubled HatesCarthaginians effect
Mod378 - 02/14 : doubled HatesEasterners effect
Mod379 - 02/14 : doubled HatesEgyptians effect
Mod380 - 02/14 : doubled HatesGreeks effect
Mod381 - 02/14 : doubled HatesRomans effect
Mod382 - 02/14 : doubled HatesSlaves effect
Mod383 - 02/14 : doubled HatesBarbarians effect
Mod384 - 02/14 : doubled HatesCarthaginians effect
Mod385 - 02/14 : doubled HatesEasterners effect
Mod386 - 02/14 : doubled HatesEgyptians effect
Mod387 - 02/14 : doubled HatesGreeks effect
Mod388 - 02/14 : doubled HatesRomans effect
Mod389 - 02/14 : doubled HatesSlaves effect

02/17

Mod390 - 02/17 : doubled threshold
Mod391 - 02/17 : doubled both good commander effects
Mod392 - 02/17 : doubled good commander effect
Mod393 - 02/17 : doubled both good commander effects
Mod394 - 02/17 : doubled good commander effect
Mod395 - 02/17 : doubled good commander effect
Mod396 - 02/17 : doubled both good commander effects
Mod397 - 02/17 : doubled good commander effect
Mod398 - 02/17 : doubled both good commander effects
Mod399 - 02/17 : doubled good commander effect
Mod400 - 02/17 : doubled good commander effect
Mod401 - 02/17 : removed two levels, set threshold at 1, reduced troop morale pentalty to -1
Mod402 - 02/17 : increased haemophobic effect to 8

02/25

Mod403 - 02/25 : doubled threshold
Mod404 - 02/25 : doubled badcommander effect
Mod405 - 02/25 : doubled threshold
Mod406 - 02/25 : doubled goodattacker effect
Mod407 - 02/25 : doubled goodattacker effect
Mod408 - 02/25 : doubled goodattacker effect
Mod409 - 02/25 : doubled threshold
Mod410 - 02/25 : doubled badattacker effect
Mod411 - 02/25 : doubled threshold
Mod412 - 02/25 : doubled gooddefender effect
Mod413 - 02/25 : doubled gooddefender effect
Mod414 - 02/25 : doubled gooddefender effect
Mod415 - 02/25 : doubled threshold
Mod416 - 02/25 : doubled baddefender effect
Mod417 - 02/25 : doubled threshold
Mod418 - 02/25 : doubled threshold
Mod419 - 02/25 : doubled goodambusher effect
Mod420 - 02/25 : doubled badambusher effect
Mod421 - 02/25 : doubled goodambusher effect
Mod422 - 02/25 : doubled threshold again
Mod423 - 02/25 : doubled threshold
Mod424 - 02/25 : doubled goodsiegeattacker effect
Mod425 - 02/25 : doubled goodsiegedefender effect
Mod426 - 02/25 : doubled badsiegeattacker effect
Mod427 - 02/25 : doubled badsiegedefender effect
Mod428 - 02/25 : doubled goodsiegeattacker effect
Mod429 - 02/25 : doubled threshold again
Mod430 - 02/25 : doubled threshold
Mod431 - 02/25 : doubled threshold
Mod432 - 02/25 : doubled brave effect
Mod433 - 02/25 : doubled brave effect
Mod434 - 02/25 : doubled brave effect
Mod435 - 02/25 : doubled brave effect
Mod436 - 02/25 : doubled brave effect
Mod437 - 02/25 : doubled threshold
Mod438 - 02/25 : doubled threshold
Mod439 - 02/25 : doubled berserker effect
Mod440 - 02/25 : doubled berserker effect
Mod441 - 02/25 : doubled berserker effect
Mod442 - 02/25 : doubled threshold
Mod443 - 02/25 : doubled coward effect
Mod444 - 02/25 : doubled coward effect
Mod445 - 02/25 : doubled threshold
Mod446 - 02/25 : doubled warlord effect
Mod447 - 02/25 : doubled warlord effect
Mod448 - 02/25 : doubled threshold
Mod449 - 02/25 : doubled threshold
Mod450 - 02/25 : doubled victorothersvirtue effect
Mod451 - 02/25 : doubled victorromanvirtue effect
Mod452 - 02/25 : doubled victorothersvirtue effect
Mod453 - 02/25 : doubled victorromanvirtue effect
Mod454 - 02/25 : doubled victorothersvirtue effect
Mod455 - 02/25 : doubled victorromanvirtue effect
Mod456 - 02/25 : doubled threshold
Mod457 - 02/25 : doubled tacticalskill effect
Mod458 - 02/25 : doubled tacticalskill effect
Mod459 - 02/25 : doubled tacticalskill effect
Mod460 - 02/25 : doubled tacticalskill effect
Mod461 - 02/25 : doubled tacticalskill effect

02/27

Mod462 - 02/27 : removed law bonus
Mod463 - 02/27 : lowered influence bonus of level 5
Mod464 - 02/27 : reduced hitpoint bonus to 1 per level
Mod465 - 02/27 : removed squalor penalty, added influence penalty
Mod466 - 02/27 : removed influence penalty, added squalor penalty
Mod467 - 02/27 : reduced influence bonus by 1 per level, removed troopmorale bonus at level three
Mod468 - 02/27 : lowered squalor bonus
Mod469 - 02/27 : added influence penalty to high levels

02/28

Mod470 - 02/28 : added IconflictType
Mod471 - 02/28 : added percentage enemy killed condition
Mod472 - 02/28 : added percentage enemy killed condition
Mod473 - 02/28 : added percentage enemy killed condition
Mod474 - 02/28 : added percentage enemy killed condition
Mod475 - 02/28 : added percentage enemy killed condition
Mod476 - 02/28 : added percentage enemy killed condition
Mod477 - 02/28 : changed second odds to 2 from 3
Mod478 - 02/28 : changed odds to 2 from 3
Mod479 - 02/28 : added percentage enemy killed condition
Mod480 - 02/28 : added percentage enemy killed condition
Mod481 - 02/28 : added percentage enemy killed condition
Mod482 - 02/28 : added percentage enemy killed condition
Mod483 - 02/28 : fixed MP percentage parameter
Mod484 - 02/28 : doubled all combat section effects for testing of new fix
Mod485 - 02/28 : new traits for fixing of doubled combat triggers
Mod486 - 02/28 : new triggers to fix doubled trigger problem
Mod487 - 02/28 : new trigger to wipe bugfix at eot
Mod488 - 02/28 : removed generalfoughtincombat for numkills = 0
Mod489 - 02/28 : added advisebuild condition, increased chance
Mod490 - 02/28 : combined this and governing9
Mod491 - 02/28 : tripled effect
Mod492 - 02/28 : split good attacker and defender triggers
Mod493 - 02/28 : reduced natural military skill chance
Mod494 - 02/28 : removed good commander effect
Mod495 - 02/28 : removed good commander effect
Mod496 - 02/28 : scaled up threshold
Mod497 - 02/28 : tripled effect, reduced chance
Mod498 - 02/28 : tripled effect, reduced chance
Mod499 - 02/28 : removed all <= and >= inequalities due to possible conflict - replaced with equivalent statements
Mod500 - 02/28 : removed trigger
Mod501 - 02/28 : removed high cap on battleodds
Mod502 - 02/28 : changed battleodds
Mod503 - 02/28 : changed battleodds
Mod504 - 02/28 : removed high cap on battleodds
Mod505 - 02/28 : changed battleodds
Mod506 - 02/28 : changed battleodds, increased gloriousfool chance
Mod507 - 02/28 : changed battleodds
Mod508 - 02/28 : added high cap on battleodds
Mod509 - 02/28 : removed high cap on battleodds
Mod510 - 02/28 : changed battleodds
Mod511 - 02/28 : removed high cap on battleodds
Mod512 - 02/28 : removed high cap on battleodds
Mod513 - 02/28 : removed high cap on battleodds
Mod514 - 02/28 : removed high cap on battleodds
Mod515 - 02/28 : set battleodds at 1
Mod516 - 02/28 : new trigger, adding to double trigger bugfix
Mod517 - 02/28 : changed chance to 50, added advise build condition

03/02

Mod518 - 03/02 : changed conditions, added not routs, changed effect to brave
Mod519 - 03/02 : changed conditions, removed brave effect
Mod520 - 03/02 : changed conditions, added not routs
Mod521 - 03/02 : reduced chance, increased range of loyalty level and lowered minimum tax requirement

===== The Cherry Vanilla Pack version: 1.1 ==== 

- Specific Changes:

- export_descr_character_traits.txt

02/10

Mod285 - 02/10 : changed ratio to 0.5
Mod286 - 02/10 : changed ratio to 0.5
Mod287 - 02/10 : changed ratio to 0.5
Mod288 - 02/10 : Changed chance to 100
Mod289 - 02/10 : changed characters from family to all
Mod290 - 02/10 : changed characters from family to all
Mod291 - 02/10 : changed effect to goodassassin from natural assassin skill
Mod292 - 02/10 : changed effect to goodassassin from natural assassin skill
Mod293 - 02/10 : added condition was attacker as per 1.2 patch
Mod294 - 02/10 : changed first odds to 1.0 from 1.5

Note: These are inclusive of the RTW 1.2 patch changes with some minor corrections.

===== The Cherry Vanilla Pack version: 1.02 ==== 

- Specific Changes:

- export_descr_character_traits.txt

11/21

bug12 - 11/21 : Fixed senate offices bug
Corrected two typos (our errors)

===== The Cherry Vanilla Pack version: 1.0 ==== 

- Specific Changes:

- export_descr_character_traits.txt

10/19

Bug1 - 10/19 : changed bonus from PopularStanding to Influence, levels 2-5
Bug2 - 10/19 : changed to "and WonBattle" from "and not WonBattle"
Bug3 - 10/19 : renamed trigger to "Loss" from "Victory" for clarity
Bug4 - 10/19 : ForeignTastesRomanVice is diplomat only. Exchanged for Rabblerouser, an underutilized roman only trait.
Bug5 - 10/19 : added not CultureType roman (see Trigger battle1r)

10/20

Bug6 - 10/20 : removed duplicate trigger with same name, combined effects (might have prevented one of them from working)
Bug7 - 10/20 : added "PercentageEnemyKilled > 10" condition to prevent coward trait being awarded when enemy retreats without fighting
Bug8 - 10/20 : changed from "and CultureType roman" to "and not CultureType roman"
Mod1 - 10/20 : Doubled Threshold, added 1 law bonus per level starting at 3, influence bonus to levels 4 and 5
Mod2a - 10/20 : Created new level "Inept_Commander", influence penalty at levels 3/4/5, changed threshold levels 3+
Mod3 - 10/20 : Lowered Attack from levels 2 and 4, added movement bonus to levels 2 and 4, increased threshold
Mod4 - 10/20 : removed a level, shuffled attack penalty and thresholds
Mod5 - 10/20 : Removed two levels, shuffled defense bonus and thresholds, increased threshold
Mod6 - 10/20 : removed a level, shuffled defense penalty and thresholds
Mod7 - 10/20 : added some hit point bonus scaling down to penalty, reduced penalties a bit, removed command star
Mod13a - 10/20 : Reduced troop morale bonuses at levels 3 and 4
Mod14 - 10/20 : increased threshold of first level, added antitrait Prim
Mod15 - 10/20 : Removed Morale effects, added PersonalSecurity penalty and Fertility bonus, increased Influence penalty
Mod16 - 10/20 : removed Popularity Standing, lowered management bonus, added Influence, Unrest, and Morale penalties
Mod17 - 10/20 : added TroopMorale
Mod18 - 10/20 : Added Command Penalties, reduced TroopMorale
Mod19 - 10/20 : Removed a level, removed a star from level 2, added siege engineering bonus, shuffled thresholds
Mod20 - 10/20 : removed a level, reduced stars, added construction bonus, shuffled thresholds.
Mod21 - 10/20 : Lowered Morale bonus, added influence bonus to levels 4 and 5, added Training discount levels 3/4/5
Mod22a - 10/20 : removed popularity penalty, lowered Morale Bonus, added Command and Influence penalties
Mod23 - 10/20 : Increased Morale at level 5, added 1 Influence at level 5

10/21

Mod24 - 10/21 : Last Level - added two hitpoints, removed TroopMorale penalty, increased threshold
Mod25 - 10/21 : Added 5% movement penalty per level
Mod26 - 10/21 : added two management to last level, scaled movement bonus to 5% per level
Mod27 - 10/21 : reduced threshold
Mod28 - 10/21 : reduced threshold
Mod13b - 10/21 : removed a level, removed pop/senate standing effects, added influence penalty
Mod30b - 10/21 : Levels 2 and 4 - reduced command stars, added troop morale. added influence levels 4 and 5
Mod2b - 10/21 : added AntiTrait "Warlord", "Renown"
Mod22b - 10/21 : Added Antitrait "Warlord"
Mod30a - 10/21 : Added AntiTrait "Coward, BadCommander"
Mod34a - 10/21 : Removed "ExcludeCultures barbarian"
Mod34b - 10/21 : added two more levels to the progression
Mod34c - 10/21 : added -1 squalor per level
Mod37a - 10/21 : Removed "ExcludeCultures barbarian"
Mod37b - 10/21 : Added two more levels to the progression
Mod37c - 10/21 : added 1 unrest per level
Mod42 - 10/21 : removed a level, -5% popstanding to levels 2 and 3
Mod43a - 10/21 : doubled threshold, scaled electability with levels
Mod44 - 10/21 : removed "ExcludeCultures barbarian", increase Influence of last level from -1, doubled threshold
Mod45 - 10/21 : reduced command star from level 2, added management. doubled threshold, added GloriousFool to antitrait
Mod46 - 10/21 : reduced one Ambush per level, doubled threshold, added GloriousFool to antitrait
Mod47 - 10/21 : doubled threshold, added antitrait Gambling
Mod48 - 10/21 : doubled threshold
Mod49a - 10/21 : added law to first level, delayed influence to level 2, increased threshold 1/level
Mod49b - 10/21 : added antitrait ignorance
Mod50 - 10/21 : added "PoliticsSkill" to antitraits
Mod51 - 10/21 : doubled threshold

10/23

Mod52 - 10/23 : doubled threshold
Mod53 - 10/23 : doubled threshold, added -1 squalor per level
Mod54 - 10/23 : reduced personal security at levels 2 and 3
Mod55 - 10/23 : removed trading bonus. added -1 management per level
Mod57 - 10/23 : removed "ExcludeCultures egyptian, barbarian", reduced personal security decrease by 90%, halved threshold
Mod58 - 10/23 : reduced training agents to 1/level, added line of sight 2/level, added influence 3rd level
Mod59 - 10/23 : reduced training agents to 1/level, increased personal security to 1/level
Mod60 - 10/23 : reduced influence bonus from "2" to "0" at level 2
Mod61 - 10/23 : removed two levels, doubled threshold
Mod63 - 10/23 : Increased threshold from 1,3,6, added -5% trading per level
Mod64 - 10/23 : added 1 Influence to level 2
Mod65 - 10/23 : reduced briberesistance to 2,3,4 instead of 2,4,6. increased threshold from 1,3,6
Mod66 - 10/23 : increased threshold from 1,3,6
Mod67 - 10/23 : increased threshold from 1,3,8
Mod68 - 10/23 : reduced first level threshold from 3
Mod69 - 10/23 : reduced bribe resistance from -2,-4,-6
Mod70 - 10/23 : reworked trait as a non-roman counterpart to RhetoricSkill

10/24

Bug9 - 10/24 : new coward trigger for defeats without engagement

10/26

Mod43b - 10/26 : added Feck and Lewd to antitraits
Mod71 - 10/26 : cut a level, changed threshold from 2,3,4,5 to 2,4,8
Mod72 - 10/26 : new trait
Mod73 - 10/26 : reduced threshold from 24,48,60
Mod74 - 10/26 : increased threshold from 1,3,6
Mod75 - 10/26 : increased threshold from 1,3,7
Mod76 - 10/26 : increased threshold from 1,3,7
Mod77 - 10/26 : increased threshold from 2,3,7
Mod78 - 10/26 : increased threshold from 2,3,7

10/28

Bug10 - 10/28 : fixed trait so its actually awarded
Bug11 - 10/28 : fixed trait so its actually awarded
Mod79 - 10/28 : kept influence stable, additional -1 personal security to all levels, raised thresh from 1,3,6, added +1 unrest per level
Mod80 - 10/28 : removed Influence bonus, added -1 Influence to all levels, added -1 unrest per level, raised thresh from 1,3,7
Mod81 - 10/28 : doubled squalor bonus
Mod82 - 10/28 : 6x the threshold
Mod83 - 10/28 : reduced TroopMorale at level 2 to 1, added two TroopMorale at level 3
Mod84 - 10/28 : removed Influence penalty at level 2
Mod85 - 10/28 : reduced troop morale penalty at level 3 from "-4" to "-3"
Mod86 - 10/28 : removed command bonuses/penalties
Mod87 - 10/28 : matched negative senate standing at levels 1/2 with pop standing bonus, added 1 thresh levels 1/2
Mod88 - 10/28 : raised thresh from 1,2,4
Mod89 - 10/28 : added negative senate standing of 5% per level, added -1 unrest per level starting at level 2, raised threshold
Mod90 - 10/28 : added senate standing bonus of 5% per level, delayed unrest penalty to level 2, raised threshold
Mod91 - 10/28 : reduced threshold of first level, substituted influence bonus for -1 static, added -1 squalor per level, added antitrait Cheapskate
Mod92 - 10/28 : reduced one from management bonus to all levels, doubled threshold
Mod94 - 10/28 : doubled threshold, static +1 influence instead of scaling
Mod95 - 10/28 : raised threshold
Mod96 - 10/28 : increased line of sight by 1 all levels.
Mod98 - 10/28 : raised threshold
Mod99 - 10/28 : reduced hit point bonus by 50%
Mod100 - 10/28 : removed a level, removed "ExcludeCultures barbarian", raised threshold
Mod101 - 10/28 : removed a level, removed "ExcludeCultures barbarian", raised threshold
Mod102 - 10/28 : removed a level, raised threshold
Mod103 - 10/28 : removed a level, raised threshold
Mod104 - 10/28 : removed a level, raised threshold
Mod105 - 10/28 : removed a level, raised threshold
Mod106 - 10/28 : removed a level, raised threshold, removed troop morale penalty
Mod107 - 10/28 : removed a level, raised threshold, removed troop morale bonus
Mod108 - 10/28 : removed a level, raised threshold, removed troop morale penalty
Mod109 - 10/28 : removed a level, raised threshold, removed troop morale bonus
Mod110 - 10/28 : removed a level, raised threshold, removed troop morale penalty
Mod111 - 10/28 : removed a level, raised threshold, removed troop morale bonus
Mod112 - 10/28 : removed a level, raised threshold, removed troop morale penalty
Mod113 - 10/28 : removed a level, raised threshold, removed troop morale bonus
Mod114 - 10/28 : removed a level, raised threshold, removed troop morale penalty
Mod115 - 10/28 : removed a level, raised threshold, removed troop morale bonus
Mod116 - 10/28 : removed a level, raised threshold, removed troop morale penalty, removed personal security penalty
Mod117 - 10/28 : removed a level, raised threshold, removed troop morale penalty, removed personal security bonus
Mod118 - 10/28 : reduced inf penalty at level 2, added management penalty at level 2, added fertility penalty starting at level 2 increasing level 5, added antitraits Fertile
Mod119 - 10/28 : removed a level
Mod120 - 10/28 : removed two levels, removed command bonuses
Mod121 - 10/28 : lowered threshold of last level
Mod122 - 10/28 : tripled threshold
Mod123 - 10/28 : added static -1 unrest, tripled threshold
Mod124 - 10/28 : removed troop morale bonus at level 2, reduced penalty at level 3
Mod125 - 10/28 : raised management to +1/level
Mod126 - 10/28 : added 1 influence per level, added antitrat Miserly
Mod127 - 10/28 : removed construction, taxcollection, and squalor modifiers. Added +1 management -1 influence per level
Mod128 - 10/28 : removed attack penalty, reduced hitpoint penalty to 1 per level
Mod129 - 10/28 : added PathologicalLiar to antitraits

11/02

Mod130 - 11/02 : removed troop morale penalty, added -1 command and -1 management per level, doubled threshold
Mod131 - 11/02 : removed influence bonus at level 1, added -1 influence to all levels, added -1 troop morale per level, removed command and management penalties, doubled threshold
Mod132 - 11/02 : reworked personal security to -1 per level, new level, 5% bribe resistance per level, added -1 command per level starting at 3, changed influence to -2 inf per level starting at level 3
Mod133 - 11/02 : added -1 command per level, added 2 troop morale at level 2, added 3 troopmorale at level 3
Mod134 - 11/02 : added berserker to anti-trait, added -1 command to level 3, increased threshold from 1,2,3
Mod135 - 11/02 : changed antitrait to strategicskill, doubled threshold
Mod136 - 11/02 : -1 influence to levels 2 and 3, -1 management to level 3, +1 troop morale to level 1, -1 troop morale to level 3
Mod137 - 11/02 : doubled threshold
Mod138 - 11/02 : doubled threshold, added -1 troop morale per level
Mod139 - 11/02 : removed bribe resistance penalty, doubled threshold
Mod140 - 11/02 : Changed threshold from 8,16,32
Mod141 - 11/02 : Added -1 squalor to levels 2 and 3, added 1 influence to levels 2 and 3, doubled threshold, added antitrait arse
Mod142 - 11/02 : reduced influence to 4
Mod143 - 11/02 : removed inf bonus, added +1 management
Mod144 - 11/02 : reduced inf bonus to 2
Mod145 - 11/02 : reduced influence bonus to 2
Mod146 - 11/02 : reduced command bonus by 1
Mod147 - 11/02 : reduced threshold of third level
Mod148 - 11/02 : removed antitrait, added 1 troop morale per level
Mod149 - 11/02 : added -2 troop morale per level, removed antitrait
Mod150 - 11/02 : removed command bonus, added 1 influence and troop morale per level
Mod151 - 11/02 : removed a level
Mod152 - 11/02 : added two law
Mod153 - 11/02 : added -2 briberesistance
Mod154 - 11/02 : added antitrait MathematicSkill

11/03

Mod155 - 11/03 : cut a level, raised threshold of level 2
Mod156 - 11/03 : cut a level, raised threshold of level 2
Mod157 - 11/03 : cut a level, raised threshold of level 2
Mod158 - 11/03 : cut a level, raised threshold of level 2
Mod159 - 11/03 : new trait
Mod160 - 11/03 : new trait
Mod162 - 11/03 : new trait
Mod163 - 11/03 : new triggers

Mod164 - 11/03 : New trigger
Mod165 - 11/03 : reduced goodcommander value
Mod166 - 11/03 : changed values due to modified thresholds
Mod167 - 11/03 : changed good commander value
Mod168 - 11/03 : added HardToBribe to trigger
Mod169 - 11/03 : added fastagent2 to trigger
Mod170 - 11/03 : added fastagent3 to trigger
Mod171 - 11/03 : added fastagent to trigger
Mod172 - 11/03 : added siege/ambush triggers
Mod173 - 11/03 : changed I_ConflictType condition, doubled chance, reduced battle odds to 0.16
Mod174 - 11/03 : added glorious fool effect, changed trait to badattacker, doubled chance and effect, changed odds to < 0.25
Mod175 - 11/03 : doubled chance, changed trait to baddefender, changed I_ConflictType condition, changed odds to < 0.25
Mod176 - 11/03 : changed trait to gooddefender, changed I_ConflictType condition, increased bonus, changed odds to < 0.25
Mod177 - 11/03 : changed to goodattacker trait, doubled effect, changed odds to < 0.25
Mod178 - 11/03 : removed trigger
Mod179 - 11/03 : removed trigger
Mod180 - 11/03 : removed trigger
Mod181 - 11/03 : removed trigger
Mod182 - 11/03 : doubled chance, reduced battle odds to 0.25, changed I_ConflictType condition
Mod183 - 11/03 : reduced battle odds to 0.25, changed I_ConflictType condition
Mod184 - 11/03 : doubled chance, reduced battle odds to 0.25
Mod185 - 11/03 : reduced battle odds to 0.25
Mod186 - 11/03 : doubled chance, reduced battle odds to 0.25
Mod187 - 11/03 : reduced battle odds to 0.25
Mod188 - 11/03 : Added "and PercentageEnemyKilled > 25" to make sure only real engagements give stars, no more pushing
Mod189 - 11/03 : Separated trigger into 5 tiers depending on good commander level, added new effects
Mod190 - 11/03 : new trigger
Mod191 - 11/03 : doubled chance
Mod192 - 11/03 : doubled chance
Mod193 - 11/03 : changed ratio to 25 from 30
Mod194 - 11/03 : changed ratio to 25 from 30
Mod195 - 11/03 : changed ratio to 25 from 30
Mod196 - 11/03 : changed chance to 50 from 20
Mod197 - 11/03 : changed odds to >= instead of >, doubled chance
Mod198 - 11/03 : changed odds from "0.8 < x < 1.5" to "1.5 < x < 3", doubled chance

11/04

Mod199 - 11/04 : new trait
Mod200 - 11/04 : new trait
Mod201 - 11/04 : removed I_ConflictType
Mod202 - 11/04 : removed I_ConflictType
Mod203 - 11/04 : removed I_ConflictType
Mod204 - 11/04 : removed I_ConflictType
Mod205 - 11/04 : removed I_ConflictType
Mod206 - 11/04 : removed I_ConflictType
Mod207 - 11/04 : removed I_ConflictType
Mod208 - 11/04 : removed I_ConflictType
Mod209 - 11/04 : removed I_ConflictType
Mod210 - 11/04 : removed I_ConflictType
Mod211 - 11/04 : removed I_ConflictType
Mod212 - 11/04 : removed I_ConflictType
Mod213 - 11/04 : added good commander effect
Mod214 - 11/04 : increased loyalty requirement, increased chance
Mod215 - 11/14 : increased from chance 3, decreased tax

11/14

Mod216 - 11/14 : increased from chance 7, decreased tax
Mod217 - 11/14 : added good admin effect
Mod218 - 11/14 : added bad admin effect
Mod219 - 11/14 : added bad admin effect
Mod220 - 11/14 : added bad admin effect
Mod221 - 11/14 : added bad admin effect
Mod222 - 11/14 : increased effect
Mod223 - 11/14 : increased effect
Mod224 - 11/14 : added bad admin effect
Mod225 - 11/14 : added bad admin effect
Mod226 - 11/14 : added bad admin effect
Mod227 - 11/14 : added bad admin effect
Mod228 - 11/14 : doubled treasury requirement, changed from bad admin to embezzler
Mod229 - 11/14 : doubled treasury requirement
Mod230 - 11/14 : doubled treasury requirement
Mod231 - 11/14 : doubled treasury requirement
Mod232 - 11/14 : added bad admin/engineer effects, increased chance
Mod233 - 11/14 : added tax requirement
Mod234 - 11/14 : added tax requirement
Mod235 - 11/14 : added tax requirement
Mod236 - 11/14 : removed trigger
Mod237 - 11/14 : reduced management requirement
Mod238 - 11/14 : removed movement point requirements, random %, doubled chance
Mod239 - 11/14 : reduced chance
Mod240 - 11/14 : decreased chance, increased effect of hypochondriac
Mod241 - 11/14 : removed risky attacker
Mod242 - 11/14 : reduced chance
Mod243 - 11/14 : removed bad siege defender trigger
Mod244 - 11/14 : lowered good trade effect
Mod245 - 11/14 : reduced chance
Mod246 - 11/14 : removed good spy condition
Mod248 - 11/14 : removed smoothtalker effect
Mod249 - 11/14 : lowered random percent, increased chance
Mod250 - 11/14 : changed equality
Mod251 - 11/14 : changed equality
Mod252 - 11/14 : changed equality
Mod253 - 11/14 : lowered chance
Mod254 - 11/14 : changed equality
Mod255 - 11/14 : changed equality
Mod256 - 11/14 : changed equality
Mod257 - 11/14 : changed equality, reduced chance
Mod258 - 11/14 : changed equality, reduced chance
Mod259 - 11/14 : changed equality
Mod260 - 11/14 : changed equality
Mod261 - 11/14 : capped to level 4
Mod262 - 11/14 : changed equality
Mod263 - 11/14 : changed equality
Mod264 - 11/14 : changed equality
Mod265 - 11/14 : capped at 3
Mod266 - 11/14 : changed equality
Mod267 - 11/14 : capped at 4
Mod268 - 11/14 : new trigger
Mod269 - 11/14 : removed movement percentage requirement, lowered random percent
Mod270 - 11/14 : changed equality
Mod271 - 11/14 : added pathological liar effect
Mod272 - 11/14 : new trigger
Mod273 - 11/14 : capped at 4
Mod274 - 11/14 : changed equality, reduced chance
Mod275 - 11/14 : changed equality, reduced chance
Mod276 - 11/14 : changed equality
Mod277 - 11/14 : removed trusting, added disciplinarian
Mod278 - 11/14 : changed equality, reduced chance
Mod279 - 11/14 : changed equality

11/18

Mod280 - 11/18 : adjusted values for initial threshold
Mod281 - 11/18 : increased threshold of level 2
Mod282 - 11/18 : removed risky* effects
Mod283 - 11/18 : removed superfluous effect
Mod284 - 11/18 : removed risky* effects

- export_VnVs.txt

10/19

Typo1 - 10/19 : renamed to "Defender" from "in Defence"
Typo3 - 10/19 : changed from "hamfisted" to "ham-fisted"
Typo4 - 10/19 : changed "is" to "are"
Typo6 - 10/19 : changed from "timidity" to "spinelessness"
Typo7 - 10/19 : removed hyphen from "almost-suicidal"
Typo8 - 10/19 : added hyphen to "Bloodyhanded" epithet
Typo9 - 10/19 : changed "customers" to "customs"
Typo10 - 10/19 : added hyphens to "day to day"
Typo11 - 10/19 : renamed from "Tit" to "Twit"
Typo12 - 10/19 : added "the" to epithet
Typo15 - 10/19 : rephrased end of sentence from "spying, as such, honest�"
Typo16 - 10/19 : added quotation marks to "right thing"
Typo17 - 10/19 : removed ", mostly" for clarity
Typo18 - 10/19 : changed from "ass" to "donkey" for clarity
Typo20 - 10/19 : changed from "ass" to "donkey" for clarity
Typo21 - 10/19 : proper punctuation
Typo22 - 10/19 : proper punctuation
Typo25 - 10/19 : changed epithet from "Editor" to "Munerator"
Typo26 - 10/19 : removed "Hero-" from trait name, for clarity
Typo27 - 10/19 : changed epithet from "Editor" to "Munerator"
Typo30 - 10/19 : proper punctuation
Typo31 - 10/19 : removed hyphen from "ship-handling"
Typo32 - 10/19 : renamed from "Been in the Wars" to "Proud Veteran" for clarity
Typo33 - 10/19 : rephrased for clarity
Typo34 - 10/19 : proper punctuation
Typo35 - 10/19 : rephrased second sentence for clarity
Typo36 - 10/19 : removed hyphen from "desert-dwellers"
Typo37 - 10/19 : changed from "the road" to "a road"
Typo38 - 10/19 : proper punctuation
Typo39 - 10/19 : rephrased second sentence for clarity
Typo40 - 10/19 : proper punctuation
Typo41 - 10/19 : changed from "up the - " to "surprise"
Typo42 - 10/19 : removed hyphen from "no-one"
Typo43 - 10/19 : rephrased for clarity
Typo44 - 10/19 : renamed from "Repellent" to "Repulsive"
Typo45 - 10/19 : proper punctuation
Typo46 - 10/19 : proper punctuation
Typo47 - 10/19 : rephrased for clarity
Typo48 - 10/19 : proper punctuation
Typo49 - 10/19 : proper punctuation
Typo51 - 10/19 : proper punctuation
Typo52 - 10/19 : proper punctuation
Typo53 - 10/19 : proper punctuation
Typo55 - 10/19 : proper punctuation
Typo56 - 10/19 : changed from "beggars" to "bugs"
Typo57 - 10/19 : proper punctuation
Typo58 - 10/19 : proper punctuation
Typo59 - 10/19 : changed from "which" to "that"
Typo60 - 10/19 : proper punctuation
Typo61 - 10/19 : changed from "none the less" to "nonetheless"
Typo62 - 10/19 : proper punctuation
Typo63 - 10/19 : proper punctuation
Typo64 - 10/19 : rephrased and renamed due to bug in trait awarding
Typo65 - 10/19 : proper punctuation
Typo66 - 10/19 : changed from "in to" to "into"
Typo67 - 10/19 : changed from "in to" to "into"
Typo68 - 10/19 : added "a" between "without" and "trace"
Typo70 - 10/19 : changed from "impenetrable" to "incomprehensible"
Typo71 - 10/19 : proper punctuation
Typo73 - 10/19 : renamed from "Foolishy" to "Foolishly"
Typo74 - 10/19 : rephrased for clarity
Typo75 - 10/19 : proper punctuation
Typo76 - 10/19 : proper punctuation
Typo77 - 10/19 : proper punctuation
Typo78 - 10/19 : proper punctuation
Typo79 - 10/19 : rephrased and renamed due to bug in trait awarding
Typo80 - 10/19 : changed epithet from "Signifer" to "Aquiliferi" for accuracy
Typo81 - 10/19 : changed from "Legend" to "legend"

10/20

Typo82 - 10/20 : rephrased for contrast with Conquering Hero
Typo83 - 10/20 : rephrased for contrast with Conqueror
Bug1a - 10/20 : changed bonus from PopularStanding to Influence, levels 2-5

10/24

Typo91 - 10/24 : removed hyphen between almost and certain
Typo93 - 10/24 : removed "can", changed "get" to "gets"
Typo95 - 10/24 : changed "lusts" to "lust"
Typo96 - 10/24 : changed "lusts" to "lust"
Typo97 - 10/24 : "The first (and last) thing his enemies know of his plans is that they are dead!" rewritten for clarity
Typo99 - 10/24 : changed "be greeted and enjoyed" to "greet and enjoy"
Typo100 - 10/24 : Changed "The" to "A"
Typo101 - 10/24 : Changed "for outsiders are not to be trusted" to "as outsiders cannot be trusted"
Typo102 - 10/24 : Added comma after foreign, changed "that" to "which". Changed "hated" to "despised" and "to" to "at"
Typo103 - 10/24 : Added "that" and changed "as not being" to "are" for clarity
Typo104 - 10/24 : Added "too"
Typo105 - 10/24 : Added comma after "expert"
Typo106 - 10/24 : Changed "it" to "this"
Typo107 - 10/24 : Rephrased the original "Although usually unruffled in a crisis, no matter what the nature of the problem, this can often make this man appear uncaring" for clarity
Typo108 - 10/24 : Added "both", removed "at the same time" for clarity
Typo109 - 10/24 : Changed "the expense" to "their expense"
Typo110 - 10/24 : Changed "can be" to "is"
Typo111 - 10/24 : Changed "in attracting" to "to attract"
Typo119 - 10/24 : Added comma after "disheartening"
Typo121 - 10/24 : added "has"
Typo122 - 10/24 : Changed "in cures" to "on cures"
Typo123 - 10/24 : corrected trait name from "Intellligent"
Typo124 - 10/24 : Changed "in" to "be it" for clarity
Typo125 - 10/24 : Changed from "apparently without having to do any work " to "without apparently doing any work"
Typo127 - 10/24 : Added "acquired" for clarity
Typo128 - 10/24 : Changed from "lusts" to "desires"
Typo130 - 10/24 : Changed "an excess on" to "an excessive interest in" for clarity
Typo131 - 10/24 : Added comma after assassins, and "his" before assailants
Typo142 � 10/24 : Capitalised �General� as it is a name title
Typo144 � 10/24 : Capitalised �General� as it is a name title

----------------------------------------------
Known limitations:
----------------------------------------------
NONE

----------------------------------------------
If you encounter problems, please visit http://thetrivium.org and download the latest version to see if the issue has been resolved. 
If not, please send a bug report to: trivium@thetrivium.org

If you feel you have any suggestions that could make this software better please feel free to contact us with your suggestion.

----------------------------------------------
The Rome Total War software is property of:
Total War Software � 2002 - 2004 The Creative Assembly Limited. Total War, Rome:Total War and the Total War logo are trademarks or registered trademarks of The Creative Assembly Limited in the United Kingdom and/or other countries.
 
Published by Activision Publishing, Inc. Activision is a registered trademark of Activision, Inc. All rights reserved. 
----------------------------------------------
All trademarked names mentioned in this document and SOFTWARE are used for editorial purposes only, with no intention of infringing upon the trademarks.







