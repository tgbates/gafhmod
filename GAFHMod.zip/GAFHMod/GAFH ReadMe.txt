Genetics, Aging, Family, and Health Mod (GAFHMod0.9b) by Malrubius

v0.9b - 04/08/2005

Developer: Malrubius

Thanks: The Trivium Organization, .Spartan, Vercingetorix, and General Graka


Contact Information
-----------------------------------------------
Email: malrubius.maximus@gmail.com



Trivium Contact Information:
-----------------------------------------------
http://thetrivium.org
email: trivium@thetrivium.org

The TWC's URL: http://www.twcenter.net/
The Trivium's forum at the TWC: http://www.twcenter.net/forums/index.php?showforum=56



Description
-----------------------------------------------
The Genetics, Aging, Family, and Health Mod (GAFHMod) starts with the Cherry Vanilla Pack (CVP version 1.2.1) and adds new traits, triggers, and ancillaries involving genetics, aging, family, and health (hence the name  8^)  
This adds more depth and possibility to the game in these areas.  This mod is designed to be a standalone addition to the vanilla campaign, but can also be incorporated into other mods with little effort.  If you would like to incorporate this mod into yours, go ahead.  Just send me an email at malrubius.maximus@gmail.com so I'll know.  Include the contact information for The Trivium Organization and myself.  


-----------------------------------------------

********** WARNING! *****************
-----------------------------------------------
This mod is NOT compatible with campaigns begun using the Cherry Vanilla mod or any other mod that modifies the following files.  These files are replaced by this mod (basically any mod that makes changes to VnVs or ancillaries will NOT work after installing GAFHMod):

Data\export_descr_ancillaries.txt
Data\export_descr_ancillary_enums.txt
Data\export_descr_character_traits.txt
Data\export_descr_VnV_enums.txt
Data\text\export_ancillaries.txt
Data\text\export_VnVs.txt


I recommend you backup your original files with the included backup script and begin a new campaign after installing this mod, as the side effects may include Generals getting spy and assassin traits, and vice versa.  Traits may change names and effects upon trying to continue a saved campaign.

-----------------------------------------------
-----------------------------------------------


----------------------------------------------
File List:
----------------------------------------------
BackupGAFH.bat
Install GAFHMod.bat
Restore from BackupGAFH.bat
CVP Readme.txt
GAFH ReadMe.txt
Data\export_descr_character_traits.txt
Data\export_descr_VnVs_enums.txt
Data\export_descr_ancillaries.txt
Data\export_descr_ancillary_enums.txt
Data\text\export_VnVs.txt
Data\text\export_ancillaries.txt
URL Link Files for: TWC.net & Trivium.org
----------------------------------------------
----------------------------------------------
Installation Instructions:
----------------------------------------------
1) Unzip into Rome Total War directory.  This will create a folder
named "GAFHMod".  Open this folder.

2) Run "Backup GAFH.bat" - This will make a new folder and store your previous traits and ancillaries files. They are made +r (Read Only) to prevent accidental overwriting.

3) Run "Install GAFHMod.bat" - This will install the traits package.

You will need to close and reopen RTW if it was currently running, and you must start a new campaign.

Running "Restore from BackupGAFH.bat" will restore your original traits and ancillaries settings.
----------------------------------------------




Philosophy
-----------------------------------------------
Looking over the vanilla traits and triggers, it seemed there was much more that could be done with them and inheritance of traits from parents.  Also, I differed with the basic theory that seemed to underlie the inheritance of traits.  The vanilla game figures that sons are more likely to be the opposite of their fathers, than similar to them.  I think this is not true in reality, so this mod attempts to increase the realism of that, while still providing the option for sons to strike off on their own in an entirely different direction.  

In the vanilla game, it seems like adopted sons and son-in-laws are the best to get, because born sons seem more likely to be incompetent.  Also, it seems like a lot of the AI sons have no traits at all, which does not help them in challenging the player's dominance.  I hope this mod will help correct these things and improve the enjoyment of players.

	
Features 
-----------------------------------------------
1. New trait and antitrait for sons to take after their fathers or strike out
	on their own path.  Most of the Coming of Age triggers have been reworked 
	to incorporate these two new traits.  Half of sons take after their fathers,
	and about 38% will be the opposite.  The rest will lean neither one way or the other, 
	and be more like the typical RTW family members.  This system allows traits
	to be passed from one generation to the next, and so on, down the line.

2. New Trait for generals to track their age and apply bonuses or negatives
	based on it, such as increased hit points for youths, and decreased
	for older generals.  A similar trait exists for spies, assassins, and diplomats.
 
3. More Traits for wives to bring their genetic input into the game:
	Healthy Wife - increases fertility and makes sons more likely to be healthy
	Sickly Wife - decreases fertility and makes sons less likely to be healthy
	Intelligent Wife - increases possibility of intelligent sons; may teach her husband a thing or two
	Ignorant Wife - decreases possibility of intelligent sons; may increase her husband's ignorance.

4. More Health-related traits
	Lame - This man's battle wounds have left him lame in one leg.
	Lame from Birth - This man was born lame and he must struggle with this.
	FreeBleeder - This man has trouble staunching his wounds.

5. More Ancillaries
	Leech - To keep the four humours in proper balance.
	Noble Steed - An inspiring mount
	Disgruntled Insider - new ancillary for spies and assassins
	Concubine - Why stop at just one wife?
	Imaginary Friend - to accompany your crazy nephew
	Blind Prophet - to foretell your coming


GAFHMod includes the following working traits and triggers:
HealthyWife, SicklyWife, Haemophiliac, Lame, LameFromBirth, IntelligentWife,
IgnorantWife, TurnsAlive (four varieties - for generals, diplomats, spies, and assassins), CharacterAges (for tracking whether character age can be tracked), TakesAfterDad, NotLikeDad, SomethingToProve, NothingToProve.

Added Ancillaries and triggers:
leech, leech2, leech_egyptian, noble_steed, disgruntled_insider, concubine,
imaginary_friend, blind_prophet

Modifications to triggers:
Inbred makes Haemophiliac and Lame From Birth more likely
More triggers for general's coming of age based on FatherTrait and stance toward his father (TakesAfterDad/NotLikeDad).



Known Issues
-----------------------------------------------
1. HPs may be too low for general with Haemophiliac, Lame from Birth, and Hypochondriac combined.  General gets +5 hp more than his bodyguard unit (giving a normal general 7hp to start), so this may not be a huge problem, although a general with all three of those traits may want to stay out of combat!  Haemophiliac and Lame from Birth each subtract 1hp, and Hypochondriac subtracts from 1 to 3hp, so it's possible (though not likely) to have a general with only 2hp.

2. Agents (not generals) have a random starting age in-game that limits the accuracy of their respective TurnsAlive traits in this mod.  With generals, TurnsAlive = 1 means the general is 16 years old.  For the agents, I've guessed that <AgentType>TurnsAlive = 1 means they are 30 years old, but some start in their 20's and others are 40.  The effect is that some will be healthier than others at later ages.
	Could modify this further by saying initial TurnsAlive = 20 years old, and add some tests with less than 100% chance to increment TurnsAlive.
	You'd still have 60-year old diplomats who are "Middle Aged", but it would at least be less predictable.  As it stands now, you can look at the creation date of an agent, and calculate at what age they'll reach Middle Age or Senior Citizen status.




Details
-------------------------------------------------
New Traits:
1. TurnsAlive
Acquired by all generals who come of age (born sons, not adopted or married into family) after campaign starts.
Young	(16-40)			+1hp
Middle Aged (40-60)		-1 Movement
Feeling his age	 (60-70)	-2 Movement, -1hp
One Foot in the Grave (70+)	-3 Movement, -2hp

2. DiplomatTurnsAlive 
Acquired by all diplomats recruited after campaign starts.  Does not exactly correspond to age of diplomat, since ingame starting age is random.  I consider starting age
to be about 30.
Young (30-40)			+2 Movement
Middle Aged (40-60)		+1 Movement
Feeling his age	 (60-70)	-1 Movement, +1 Influence
One Foot in the Grave (70+)	-2 Movement, +2 Influence

3. SpyTurnsAlive  
Acquired by all spies recruited after campaign starts.  Does not exactly correspond to age of spy, since ingame starting age is random.  I consider starting age to be about 30.
Young (30-40)			+2 Movement
Middle Aged (40-60)		+1 Movement
Feeling his age	 (60-70)	-1 Movement
One Foot in the Grave (70+)	-2 Movement

4. AssassinTurnsAlive  
Acquired by all spies recruited after campaign starts.  Does not exactly correspond to age of spy, since ingame starting age is random.  I consider starting age to be about 30.
Young (30-40)			+2 Movement
Middle Aged (40-60)		+1 Movement
Feeling his age	 (60-70)	-1 Movement, -1 Subterfuge
One Foot in the Grave (70+)	-2 Movement, -2 Subterfuge

5. TakesAfterDad/NotLikeDad
50% chance to take after father, ~38% chance to be the opposite.
Trait has no effects, except that it is used to test what traits a son
starts with.

6. HealthyWife/SicklyWife
HealthyWife	15% chance to acquire when general marries
SicklyWife	25% chance to acquire if general didn't marry a healthy wife
Increases or decreases fertility, and also effects sons' HaleAndHearty and Hypochondriac traits, among others.

7. IntelligentWife/IgnorantWife
Increases or decreases chance of having intelligent or ignorant sons.
IntelligentWife	10% chance when general marries
IgnorantWife	25% chance when married, if wife not intelligent

8. Haemophiliac
Acquired at birth 	5% chance if Inbred, some other triggers based on parents
-1 to hit points

9. Lame
Acquired as a result of combat wounds, 5% chance each turn.
Hobbled				-1 Movement
Lame				-2 Movement

10. LameFromBirth
Acquired at birth, several triggers depending on parents
-4 Movement, -1hp, -1 Command, -1 Influence






New Ancillaries/Retainers
-----------------------------------------------
1. Leech
+1 to Public Health, +5% to healing wounds in battle.
50% chance of being acquired when a general has 100% of his movement points remaining, has the traits BlackBileHumour and Hypochondriac, and is in a settlement with a Greek Academy.

2. Leech2
Same as above, except for YellowBileHumour instead of BlackBileHumour.

3. Egyptian Leech
Same benefits as above.
25% chance of being acquired when an Egyptian general ends his turn in a settlement
with a temple of healing, with all his movement remaining, and with the Hypochondriac trait.

4. Noble Steed
+1 to command Cavalry, -1 to command infantry, +1 Influence, +1 to movement.
1% chance of acquiring when a general ends his turn in a settlement with stables, who
has the GoodCavalryGeneral trait, and has all his movement remaining.

5. Disgruntled Insider
+1 to Subterfuge, -1 to personal security (chance of being assassinated).
A spy or assassin has a 5% chance to acquire this retainer when in EnemyLands.

6. Concubine
+1 to Fertility.
A general has a 10% chance to acquire a concubine if he ends his turn in a settlement with all his movement, and has the trait Girls to a moderate degree.

7. Imaginary Friend
-1 Influence
An insane general has a 5% chance, when he comes of age, to acquire this ancillary.

8. Blind Prophet
+1 Influence, -1 to personal security.
A general has a 1% chance to acquire a blind prophet if he ends his turn in a settlement
with all his movement and has the trait TouchedByTheGods.



List of modifications
-----------------------------------------------
Character Traits
GAFHMod1 - 3/31 : new trait
GAFHMod2 - 3/31 : new trait
GAFHMod3 - 3/31 : new trait
GAFHMod4 - 3/31 : new trait
GAFHMod5 - 3/31 : new trait
GAFHMod6 - 4/1 : new trigger
GAFHMod7 - 4/1 : new trigger to acquire new trait
GAFHMod8 - 4/1 : new trigger
GAFHMod9 - 4/1 : new trigger
GAFHMod10 - 4/1 : new trigger
GAFHMod11 - 4/1 : new trigger
GAFHMod12 - 4/1 : new trigger
GAFHMod13 - 4/1 : new trigger
GAFHMod14 - 4/1 : new trigger
GAFHMod15 - 4/1 : new trigger
GAFHMod16 - 4/1 : Added AntiTraits HealthyWife and SicklyWife
GAFHMod17 - 4/1 : new trigger
GAFHMod18 - 4/1 : new trigger
GAFHMod19 - deleted
GAFHMod20 - 4/3 : new trigger
GAFHMod21 - 4/1 : new trigger
GAFHMod22- 3/31 : new trait
GAFHMod23- 3/31 : new trait
GAFHMod24 - 4/4 : Added AntiTraits IntelligentWife and IgnorantWife
GAFHMod25 - 4/4 : new trigger
GAFHMod26 - 4/4 : new trigger
GAFHMod27 - 4/4 : new trigger
GAFHMod28 - 4/4 : new trigger
GAFHMod29 - 4/4 : new trigger
GAFHMod30 - 4/4 : new trigger - wifely wisdom rubs off on hubbie
GAFHMod31 - 4/4 : new trigger - wifely ignorance rubs off on hubbie
GAFHMod32 - 4/4 : age trait for generals - change threshold if not 2 turns/year
GAFHMod33 - 4/4 : age trait for diplomats - change threshold if not 2 turns/year
GAFHMod34 - 4/4 : trait increments each season, adjust thresholds accordingly if more than 2 seasons/year
GAFHMod35 - 4/4 : starting age of general
GAFHMod36 - 4/4 : starting age of assassin - just a guess, really
GAFHMod37 - 4/4 : added starting age of spy - just a guess, really
GAFHMod38 - 4/4 : added starting age of diplomat - just a guess, really
GAFHMod39 - 4/4 : starting age of admiral - just a guess, really - not sure if AgentCreated test works
GAFHMod40 - 4/4 : trait increments each season, adjust thresholds accordingly if more than 2 seasons/year
GAFHMod41 - 4/4 : trait increments each season, adjust thresholds accordingly if more than 2 seasons/year
GAFHMod42 - 4/5 : new trigger
GAFHMod43 - 4/5 : age trait for spies - change threshold if not 2 turns/year
GAFHMod44 - 4/4 : trait increments each season, adjust thresholds accordingly if more than 2 seasons/year
GAFHMod45 - 4/5 : trait increments each season, adjust thresholds accordingly if more than 2 seasons/year
GAFHMod46 - 4/5 : age trait for assassins - change threshold if not 2 turns/year
GAFHMod47 - 4/6 : new trait for created characters (not in descr_stat.txt)
GAFHMod48 - 4/7 : new trait
GAFHMod49 - 4/7 : new trait
GAFHMod50 - 4/7 : new trait
GAFHMod51 - 4/7 : new trait
GAFHMod52 - 4/7 : new trigger
GAFHMod53 - 4/7 : new trigger
GAFHMod54 - 4/7 : new trigger
GAFHMod55 - 4/7 : new trigger
GAFHMod56 - 4/7 : new trigger
GAFHMod57 - 4/7 : new trigger
GAFHMod58 - 4/7 : new trigger
GAFHMod59 - 4/7 : new trigger
GAFHMod60 - 4/7 : new trigger
GAFHMod61 - 4/7 : new trigger
GAFHMod62 - 4/7 : new trigger
GAFHMod63 - 4/7 : new trigger
GAFHMod64 - 4/7 : new trigger
GAFHMod65 - 4/7 : new trigger
GAFHMod66 - 4/7 : new trigger
GAFHMod67 - 4/7 : new trigger
GAFHMod68 - 4/7 : new trigger
GAFHMod69 - 4/7 : new trigger
GAFHMod70 - 4/7 : new trigger
GAFHMod71 - 4/7 : new trigger
GAFHMod72 - 4/7 : new trigger
GAFHMod73 - 4/7 : new trigger
GAFHMod74 - 4/7 : new trigger
GAFHMod75 - 4/7 : new trigger
GAFHMod76 - 4/7 : new trigger
GAFHMod77 - 4/7 : new trigger
GAFHMod78 - 4/7 : split trigger for TakesAfterDad and NotLikeDad
GAFHMod79 - 4/7 : new trigger
GAFHMod80 - 4/7 : split trigger for TakesAfterDad and NotLikeDad
GAFHMod81 - 4/7 : new trigger
GAFHMod82 - 4/7 : split trigger for TakesAfterDad and NotLikeDad
GAFHMod83 - 4/7 : new trigger
GAFHMod84 - 4/7 : commented out (GAFHMod70 replaces)
GAFHMod85 - 4/7 : split trigger for TakesAfterDad and NotLikeDad
GAFHMod86 - 4/7 : new trigger
GAFHMod87 - 4/7 : split trigger for TakesAfterDad and NotLikeDad
GAFHMod88 - 4/7 : new trigger
GAFHMod89 - 4/7 : split trigger for TakesAfterDad and NotLikeDad
GAFHMod90 - 4/7 : new trigger
GAFHMod91 - 4/7 : split trigger for TakesAfterDad and NotLikeDad
GAFHMod92 - 4/7 : new trigger
GAFHMod93 - 4/7 : split trigger for TakesAfterDad and NotLikeDad
GAFHMod94 - 4/7 : new trigger
GAFHMod95 - 4/7 : split trigger for TakesAfterDad and NotLikeDad
GAFHMod96 - 4/7 : new trigger
GAFHMod97 - 4/7 : split trigger for TakesAfterDad and NotLikeDad
GAFHMod98 - 4/7 : new trigger
GAFHMod99 - 4/7 : commented out, replaced by GAFHMod66 & 67
GAFHMod100 - 4/7 : split trigger for TakesAfterDad and NotLikeDad
GAFHMod101 - 4/7 : new trigger
GAFHMod102 - 4/7 : split trigger for TakesAfterDad and NotLikeDad
GAFHMod103 - 4/7 : new trigger
GAFHMod104 - 4/7 : split trigger for TakesAfterDad and NotLikeDad
GAFHMod105 - 4/7 : new trigger
GAFHMod106 - 4/7 : split trigger for TakesAfterDad and NotLikeDad
GAFHMod107 - 4/7 : new trigger
GAFHMod108 - 4/7 : new trigger
GAFHMod109 - 4/7 : new trigger


Ancillaries
AncillaryMod1	leech
AncillaryMod2	leech2
AncillaryMod3	leech_egyptian
AncillaryMod4	noble_steed
AncillaryMod5	disgruntled_insider
AncillaryMod6-10 new triggers for new ancillaries
AncillaryMod11	concubine
AncillaryMod12	trigger for concubine
AncillaryMod13-14	Imaginary friend and trigger
AncillaryMod14-15	Blind Prophet and trigger
